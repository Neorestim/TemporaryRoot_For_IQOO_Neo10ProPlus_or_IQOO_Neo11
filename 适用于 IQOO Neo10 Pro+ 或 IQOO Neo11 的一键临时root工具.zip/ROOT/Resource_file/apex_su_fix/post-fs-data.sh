#!/system/bin/sh
while [ ! -f /apex/com.android.virt/bin/su ]; do
    sleep 1
done
mount --bind /system/bin/su /apex/com.android.virt/bin/su
